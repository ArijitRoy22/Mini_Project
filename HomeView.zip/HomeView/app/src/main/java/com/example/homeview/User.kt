package com.example.homeview

data class User(
    val firstName: String? = null
)
